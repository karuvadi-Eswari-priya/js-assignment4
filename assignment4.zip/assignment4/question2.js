let version = prompt("Enter os name and version seprated by space.");
		console.log("The os name is ${version.split(" ")[0]} and version is ${version.split(" ")[0]}");